# Time Capsule [500 pts]

**Category:** Forensic
**Solves:** 0

## Description
>> Dalam perjalanan mencari wejangan hidup, seorang *Hikki-NEET*, sebut saja Kazuma, menemukan **Time capsule** yang dicache menggunakan CDN. Di sana, ia menemukan potongan pesan yang kabarnya merupakan peninggalan dari seorang **Damegami** sehingga wajar saja apabila pesan yang ditinggalkannya dalam keadaan yang acak-acakan.

Author: Yui

**Hint**
* -

## Solution

### Flag

