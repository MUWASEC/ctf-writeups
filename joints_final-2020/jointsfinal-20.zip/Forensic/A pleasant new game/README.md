# A pleasant new game [500 pts]

**Category:** Forensic
**Solves:** 0

## Description
>>Sebuah agensi menerima **S-Rank Quest** dari client bernama Regigigas. Dalam permintaannya, Regigigas menyebutkan bahwa ia membutuhkan seseorang yang mampu memecahkan kode pada monolit dengan beberapa bekas kerusakan

Author: Yui

**Hint**
* -

## Solution

### Flag

