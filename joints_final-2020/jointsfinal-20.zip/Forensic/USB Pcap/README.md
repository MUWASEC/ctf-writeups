# USB Pcap [100 pts]

**Category:** Forensic
**Solves:** 10

## Description
>Welcome, Agent Ari SN007, glad you're back. We've been investigating a suspicious syndicate running a website on the dark web. It turns out that the website is protected by heavily secured password protection system, so there is no way we can leak the password. Fortunately, our other agent has been managed plant some sort of keylogger into one of the syndicate member. 
Your mission, should you choose to accept it, is to get the password of the website.

Author: vido21

**Hint**
* -

## Solution

### Flag

