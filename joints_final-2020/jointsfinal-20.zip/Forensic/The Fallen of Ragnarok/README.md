# The Fallen of Ragnarok [500 pts]

**Category:** Forensic
**Solves:** 0

## Description
>>In order to stop Dr. Weil's ultimate weapon, Zero sacrificed his life to take down the Ragnarok. He knew that he had no chance to return safely. Thus, he left his final message to Ciel before the Ragnarok final explosion.

Author: Yui

**Hint**
* -

## Solution

### Flag

