# Engineering [194 pts]

**Category:** Reverse Engineering
**Solves:** 7

## Description
>Author: lunashci

**Hint**
* -

## Solution

### Flag

