# Challenge [194 pts]

**Category:** Reverse Engineering
**Solves:** 8

## Description
>Flag : JOINTS20{<32-bit signed int>}

Author: Mawar

**Hint**
* -

## Solution

### Flag

