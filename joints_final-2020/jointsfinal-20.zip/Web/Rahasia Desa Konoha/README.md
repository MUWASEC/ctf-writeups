# Rahasia Desa Konoha [275 pts]

**Category:** Web
**Solves:** 6

## Description
>ctf.joints.id:10005

Tolong bantu saya mencari informasi mengenai clan Uchiha.
Saya sudah mencari di berbagai sumber, namun sepertinya informasi 
tersebut disembunyikan oleh Hokage Ketujuh.

[konoha.zip](https://drive.google.com/file/d/1OxxCmGMje8rK94JDCQW0p1YxU-_VVcps/view?usp=sharing)

Author: cacadosman

**Hint**
* -

## Solution

### Flag

