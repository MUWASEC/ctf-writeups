# KPU Joints Jaya [500 pts]

**Category:** Web
**Solves:** 0

## Description
>ctf.joints.id:10002

Pemilu tahun 2019 sudah terlewati, namun pada bulan ini, terdapat sebuah 
kasus data breach sejumlah 200 juta data yang menimpa KPU Joints Jaya.
Mohon bantu kami mencari celahnya agar bisa kami perbaiki.

[KPU_Joints_Jaya.zip](https://drive.google.com/file/d/1K7pdmqUT_sUx5gY2XIPk0QXKK_O_QzNV/view?usp=sharing)

Credits:
- cacadosman
- naifriot

**Hint**
* I think there is a vuln on nginx, but no, its actually on other service
* some dependencies may cause a vulnerability

## Solution

### Flag

