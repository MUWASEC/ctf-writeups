# SecureStringMatching [194 pts]

**Category:** Web
**Solves:** 8

## Description
>ctf.joints.id:40003

Author: vido21

**Hint**
* -

## Solution

### Flag

