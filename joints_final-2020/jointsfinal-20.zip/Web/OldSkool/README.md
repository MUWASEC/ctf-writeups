# OldSkool [500 pts]

**Category:** Web
**Solves:** 0

## Description
>ctf.joints.id:1337

Tolong testing aplikasi CurMas yang baru kami buat, terimakasih<br>
<br>
Author : Yeraisci

**Hint**
* Try to chain 2 vuln. Also i am self-ish and dont have XXXX protection on my body, very fragile.
* Flag ada di profile admin ya

## Solution

### Flag

