# diary [500 pts]

**Category:** Binex
**Solves:** 0

## Description
>`nc ctf.joints.id 17078`

Author: root

**Hint**
* -

## Solution

### Flag

