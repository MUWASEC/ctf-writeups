# LoggerV2 [500 pts]

**Category:** Binex
**Solves:** 1

## Description
>`nc ctf.joints.id 17072`

Author: root

**Hint**
* -

## Solution

### Flag

