# sorting [489 pts]

**Category:** Binex
**Solves:** 1

## Description
>`nc ctf.joints.id 17077`

Author: root

**Hint**
* -

## Solution

### Flag

