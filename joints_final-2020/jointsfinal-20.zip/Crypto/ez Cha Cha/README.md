# ez Cha Cha [475 pts]

**Category:** Crypto
**Solves:** 2

## Description
>`nc ctf.joints.id 8891`

Author: vido21

**Hint**
* -

## Solution

### Flag

