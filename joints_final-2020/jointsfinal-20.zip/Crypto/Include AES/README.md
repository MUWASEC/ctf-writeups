# Include AES [444 pts]

**Category:** Crypto
**Solves:** 2

## Description
>every website needs encryption to secure it, be careful with AES encryption on this website

ctf.joints.id:8892

Author: vido21

**Hint**
* -

## Solution

### Flag

