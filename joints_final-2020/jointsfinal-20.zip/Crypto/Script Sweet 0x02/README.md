# Script Sweet 0x02 [500 pts]

**Category:** Crypto
**Solves:** 0

## Description
>ok, i ask you once again, is your script really sweet enough ?

`nc ctf.joints.id 9997`

Author : Yeraisci

**Hint**
* agent_object = {"agent_uid":0,"agent_status":"active","agent_username":"","agent_role":"staff","agent_age":69}

## Solution

### Flag

