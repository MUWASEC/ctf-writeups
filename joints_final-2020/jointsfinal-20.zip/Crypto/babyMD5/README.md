# babyMD5 [400 pts]

**Category:** Crypto
**Solves:** 3

## Description
>`nc ctf.joints.id 8890`


Author: vido21

**Hint**
* -

## Solution

### Flag

